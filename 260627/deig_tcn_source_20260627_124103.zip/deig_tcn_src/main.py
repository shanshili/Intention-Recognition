"""
DEIG-TCN end-to-end pipeline.

Run:  python main.py [--out DIR] [--epochs N] [--quick]

Produces (all filenames carry a run timestamp; every figure saved as
png + svg + pdf):
  * candidate_directed_graph_<ts>.{png,svg,pdf}        (REQUIRED)
  * intent_graphs_10windows_<ts>.{png,svg,pdf}         (REQUIRED, 10 windows)
  * intent_graph_window_00.._09_<ts>.{png,svg,pdf}     (per-window detail)
  * training_loss_<ts>.{png,svg,pdf}
  * edge_mask_ablation_<ts>.{png,svg,pdf}
  * intent_graph_density_<ts>.{png,svg,pdf}
  * edge_intent_scores_<ts>.npz / run_summary_<ts>.json (data exports)
"""

from __future__ import annotations

import argparse
import json
import os
from datetime import datetime

import numpy as np

from deig.data import generate_synthetic, Preprocessor
from deig.graph import build_candidate_graph
from deig.features import build_window_inputs
from deig.model import (DEIG_TCN, assemble_batch, compute_reverse_index)
from deig.autograd import Adam
from deig.intent_graph import (build_intent_graph, extract_hotspots,
                               node_intent_attributes)
from deig import viz


def make_windows(T, W, H, train_frac=0.6, val_frac=0.2, stride=4):
    starts = list(range(W - 1, T - H, stride))
    M = len(starts)
    tr = int(train_frac * M)
    va = int((train_frac + val_frac) * M)
    return starts[:tr], starts[tr:va], starts[va:]


def build_inputs_for(pre, cand, t_list, W, H):
    Z = pre["Z"]
    inputs, targets = [], []
    for t in t_list:
        wi = build_window_inputs(pre, cand, t, W)
        inputs.append(wi)
        targets.append(Z[:, t + 1:t + 1 + H])
    return inputs, targets


def mae(pred, target):
    return float(np.mean(np.abs(pred - target)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/mnt/user-data/outputs")
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--quick", action="store_true",
                    help="smaller/faster run for testing")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    print(f"[run] timestamp = {timestamp}")

    # ---------------- data ----------------
    if args.quick:
        data = generate_synthetic(N=20, days=90, seed=7)
        W, H, stride, epochs = 24, 6, 8, 12
    else:
        data = generate_synthetic(N=30, days=210, seed=7)
        W, H, stride, epochs = 24, 6, 6, args.epochs
    N, T = data.X.shape
    print(f"[data] N={N} sensors, T={T} hourly steps "
          f"({T/24:.0f} days), {len(data.true_chains)} corridors")

    train_end = int(0.6 * T)
    pre = Preprocessor(train_end=train_end).fit_transform(data)

    # ---------------- candidate graph ----------------
    cand = build_candidate_graph(data.coords, pre["Z"], train_end,
                                 k=4, tau_max=4)
    rev = compute_reverse_index(cand)
    print(f"[graph] candidate edges |E0|={cand['E']}")

    # ---------------- windows ----------------
    tr_t, va_t, te_t = make_windows(T, W, H, stride=stride)
    print(f"[windows] train={len(tr_t)} val={len(va_t)} test={len(te_t)}")

    print("[feat] building window features (train/val/test)...")
    tr_in, tr_y = build_inputs_for(pre, cand, tr_t, W, H)
    va_in, va_y = build_inputs_for(pre, cand, va_t, W, H)
    te_in, te_y = build_inputs_for(pre, cand, te_t, W, H)

    Fz = tr_in[0]["z"].shape[1]
    Fedge = tr_in[0]["edge_block"].shape[1]
    model = DEIG_TCN(Fz=Fz, Fedge=Fedge, H=H, hidden=32, msg_dim=16, seed=0)
    opt = Adam(model.params(), lr=5e-3, weight_decay=1e-5)
    lambdas = {"sparse": 0.02, "dir": 0.05}

    # mini-batch the training windows by concatenation
    rng = np.random.default_rng(0)
    idx_all = np.arange(len(tr_in))
    bs = 16
    history = {"pred": [], "total": []}

    print("[train] starting...")
    for ep in range(epochs):
        rng.shuffle(idx_all)
        ep_pred, ep_total, nb = 0.0, 0.0, 0
        for b0 in range(0, len(idx_all), bs):
            bidx = idx_all[b0:b0 + bs]
            batch = assemble_batch([tr_in[i] for i in bidx],
                                   [tr_y[i] for i in bidx], cand, rev)
            opt.zero_grad()
            total, logs, s, pred = model.forward_loss(batch, lambdas)
            total.backward()
            opt.step()
            ep_pred += float(logs["pred"]); ep_total += float(logs["total"])
            nb += 1
        history["pred"].append(ep_pred / nb)
        history["total"].append(ep_total / nb)
        if ep % max(1, epochs // 8) == 0 or ep == epochs - 1:
            # quick val MAE
            vb = assemble_batch(va_in, va_y, cand, rev)
            vpred = model.infer_pred(vb)
            print(f"  epoch {ep:3d}  L_pred={history['pred'][-1]:.4f}  "
                  f"L_total={history['total'][-1]:.4f}  "
                  f"val_MAE={mae(vpred, vb['target']):.4f}")

    # ---------------- test prediction ----------------
    tb = assemble_batch(te_in, te_y, cand, rev)
    tpred = model.infer_pred(tb)
    test_mae = mae(tpred, tb["target"])
    persist = np.repeat(tb["z_last"].reshape(-1, 1), H, axis=1)
    test_mae_persist = mae(persist, tb["target"])
    print(f"[test] DEIG-TCN MAE={test_mae:.4f}  "
          f"persistence MAE={test_mae_persist:.4f}")

    # ---------------- edge-mask ablation ----------------
    s_test = model.infer_scores(tb)          # per-edge scores for full test batch
    E_total = s_test.size
    k = max(1, int(0.1 * E_total))
    order = np.argsort(s_test)
    low_idx, top_idx = order[:k], order[-k:]
    rand_idx = rng.choice(E_total, size=k, replace=False)

    def mask_and_eval(mask_idx):
        s2 = s_test.copy()
        s2[mask_idx] = 0.0
        p = model.infer_pred(tb, s_override=s2)
        return mae(p, tb["target"])

    abl = {"full": test_mae,
           "mask_top": mask_and_eval(top_idx),
           "mask_random": mask_and_eval(rand_idx),
           "mask_low": mask_and_eval(low_idx)}
    print(f"[ablation] {abl}")

    # ---------------- 10 consecutive test windows ----------------
    n_show = 10
    if len(te_t) >= n_show:
        show_t = te_t[:n_show]
        show_in = te_in[:n_show]
        show_y = te_y[:n_show]
    else:  # pad by reusing
        show_t = (te_t * n_show)[:n_show]
        show_in = (te_in * n_show)[:n_show]
        show_y = (te_y * n_show)[:n_show]

    window_labels, scores_list, densities, hotspot_counts = [], [], [], []
    for k2, (t, wi, y) in enumerate(zip(show_t, show_in, show_y)):
        wb = assemble_batch([wi], [y], cand, rev)
        s = model.infer_scores(wb)
        scores_list.append(s)
        g = build_intent_graph(s, cand, q=0.90)
        densities.append(len(g["strength"]) / (N * (N - 1)))
        hs = extract_hotspots(g, min_size=2)
        hotspot_counts.append(len(hs))
        hh = (t // 24, t % 24)
        window_labels.append(f"win{k2}  t={t} (d{hh[0]} h{hh[1]})")

    # ---------------- figures (all timestamped, png+svg+pdf) ----------------
    print("[viz] writing figures...")
    produced = {}
    produced["candidate"] = viz.plot_candidate_graph(
        data.coords, cand, args.out, timestamp, chains=data.true_chains)
    produced["intent_panel"] = viz.plot_intent_windows(
        data.coords, cand, scores_list, window_labels, args.out, timestamp,
        q=0.90)
    produced["intent_single"] = []
    for k2 in range(n_show):
        produced["intent_single"].append(viz.plot_single_intent_window(
            data.coords, cand, scores_list[k2], window_labels[k2],
            args.out, timestamp, q=0.90, idx=k2))
    produced["training"] = viz.plot_training_curve(history, args.out, timestamp)
    produced["ablation"] = viz.plot_edge_mask_ablation(abl, args.out, timestamp)
    produced["density"] = viz.plot_intent_density(
        densities, window_labels, args.out, timestamp)

    # ---------------- data exports (timestamped) ----------------
    npz_path = os.path.join(args.out, f"edge_intent_scores_{timestamp}.npz")
    np.savez_compressed(
        npz_path,
        edges=cand["edges"], coords=data.coords,
        window_t=np.array(show_t),
        scores=np.array(scores_list),
        candidate_edge_feats=cand["edge_feats"])
    summary = {
        "timestamp": timestamp,
        "N": int(N), "T": int(T), "W": W, "H": H,
        "candidate_edges": int(cand["E"]),
        "train_windows": len(tr_t), "val_windows": len(va_t),
        "test_windows": len(te_t),
        "test_MAE": test_mae, "persistence_MAE": test_mae_persist,
        "edge_mask_ablation": abl,
        "intent_density_per_window": densities,
        "hotspots_per_window": hotspot_counts,
        "intent_quantile_q": 0.90,
    }
    sum_path = os.path.join(args.out, f"run_summary_{timestamp}.json")
    with open(sum_path, "w") as f:
        json.dump(summary, f, indent=2)

    print("[done] outputs in", args.out)
    return produced, summary, args.out, timestamp


if __name__ == "__main__":
    main()
